import React, { useRef } from 'react';
import { motion, useScroll, useTransform } from 'framer-motion';
import Lottie from 'react-lottie-player';
import essayLottie from './animations/essay.json'; // placeholder

export default function Home() {
  const { scrollYProgress } = useScroll();
  const heroOpacity = useTransform(scrollYProgress, [0, 0.2], [1, 0.6]);
  const reveal = {
    hidden: { opacity: 0, y: 80 },
    visible: i => ({ opacity: 1, y: 0, transition: { delay: i * 0.3, ease: 'easeOut' } })
  };

  return (
    <div className="font-['GT_Section'] bg-white text-gray-800">
      {/* Navbar */}
      <nav className="fixed w-full bg-white/40 backdrop-blur-lg z-50">
        <div className="max-w-7xl mx-auto flex justify-between items-center py-4 px-6">
          <h1 className="text-2xl font-bold">Blake Bird Coaching</h1>
          <ul className="flex space-x-8 text-lg">
            {['Home','Services','Credibility','Courses','Testimonials','Process','Pricing','Essay','Resume','Contact'].map(item => (
              <li key={item}><a href={`#${item.toLowerCase()}`} className="hover:text-rose-gold transition-colors">{item}</a></li>
            ))}
          </ul>
        </div>
      </nav>

      <main className="pt-20">
        {/* Hero Section */}
        <motion.section
          id="home"
          className="relative h-screen bg-cover bg-center"
          style={{ backgroundImage: "url('/images/hero-bg.jpg')", opacity: heroOpacity }}
          initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 1 }}>
          <div className="absolute inset-0 bg-gradient-to-br from-midnight-blue to-rose-gold/60" />
          <motion.div
            className="relative z-10 flex flex-col items-center justify-center h-full text-center px-4"
            initial={{ scale: 0.85, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} transition={{ delay: 0.6, duration: 1, ease: 'anticipate' }}>
            <motion.h2
              className="text-6xl font-serif leading-tight text-white drop-shadow-lg"
              initial={{ y: 40 }} animate={{ y: 0 }} transition={{ delay: 0.8, duration: 0.8, ease: 'easeOut' }}>
              Transform Your Academic Journey
            </motion.h2>
            <motion.p
              className="mt-6 text-2xl text-white/90 max-w-2xl"
              initial={{ y: 20, opacity: 0 }} animate={{ y: 0, opacity: 1 }} transition={{ delay: 1.0, duration: 0.8 }}>
              Bespoke Math, Physics & Essay Coaching for the ambitious mind.
            </motion.p>
            <motion.button
              className="mt-12 px-10 py-4 bg-rose-gold text-white font-medium rounded-full shadow-2xl hover:scale-105"
              whileHover={{ scale: 1.08 }} transition={{ type: 'spring', stiffness: 300 }}>
              Book Your Free Consult
            </motion.button>
          </motion.div>
        </motion.section>
        {/* ...rest of the code from our refined design... */}
      </main>
    </div>
);